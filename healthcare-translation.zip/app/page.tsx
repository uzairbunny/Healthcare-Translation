'use client';

import TranslationInterface from '../components/TranslationInterface';
import Header from '../components/Header';
import PrivacyNotice from '../components/PrivacyNotice';
import ErrorBoundary from '../components/ErrorBoundary';

export default function Home() {
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              Healthcare Translation Assistant
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Real-time multilingual communication for healthcare providers and patients. 
              Speak naturally and get instant, accurate translations with audio playback.
            </p>
          </div>
          
          <PrivacyNotice />
          <TranslationInterface />
          
          <div className="mt-12 text-center">
            <div className="bg-white rounded-lg shadow-md p-6 max-w-4xl mx-auto">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">How to Use</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-settings-3-line text-blue-600 text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">1. Select Languages</h3>
                  <p className="text-sm text-gray-600">Choose input and output languages from the dropdown menus</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-mic-line text-blue-600 text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">2. Start Speaking</h3>
                  <p className="text-sm text-gray-600">Click the microphone button and speak clearly</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-volume-up-line text-blue-600 text-xl"></i>
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">3. Listen & Communicate</h3>
                  <p className="text-sm text-gray-600">View translations and use the speak button for audio playback</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}